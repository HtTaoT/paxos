#pragma once

#include "bplustree.h"
#include <string>
using namespace std;

struct SqlData
{
    string value;
};

struct SqlDataList
{
    string key;
    void *pValue;
    int type;
    SqlDataList* pNext;
};

class smallsql
{
public:
    smallsql() {data_size = 0;}
    ~smallsql() {}

    bool open(const string & sqlPath);

    void close();
    bool get(const string &key, string &value);
    bool put(const string &key, const string &value);

public:
    static const int m_block_size = 4096;
private:
    string m_sqlPath;
    int data_size;
    bplus_tree* m_pTree;
};